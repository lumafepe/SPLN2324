#!/usr/bin/env python3

'''
Name 
    WordOccur - Calculates words Occurenceis in a text

SYNOPSIS
    WordOccur [options] input_files
    option: 
        -m 20 - Show the 20 most common
        -n: Order alfabetically

DESCRIPTIONS

'''

from collections import Counter
from jjcli import *
import re

__version__ = "0.0.1"

def tokeniza(text):
    palavras = re.findall(r'\w+(?:\-\w+)?|[,;.:?!_—]+', text)
    # ?: agrupa regex, mas não são tratadas como grupo de captura
    return palavras

def printWordsList(list):
    for word, numb in list:
        print(f"{numb}  {word}")


def main():

    cl = clfilter("nm:", doc=__doc__) ## Option values in cl.opt dictionary

    for txt in cl.text():             ## Process one file at time
        wordsList = tokeniza(txt)
    
        if "-m" in cl.opt and "-n" in cl.opt:
            wordsList.sort()
            c = Counter(wordsList)
            printWordsList(c.most_common(int(cl.opt.get("-m"))))
        elif "-m" in cl.opt:
            c = Counter(wordsList)
            printWordsList(c.most_common(int(cl.opt.get("-m"))))
        elif "-n" in cl.opt:
            wordsList.sort()
            c = Counter(wordsList)
            printWordsList(c.items())
        else:
            c = Counter(wordsList)
            printWordsList(c.items())



# chmod 755 filename, transforma o código num script